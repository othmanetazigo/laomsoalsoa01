#!\usr\bin\perl
#   Author      : I.OIRRAQ
########################################################################################################################
use warnings;
use strict;
use Cwd; 


# LOOP THROUGH RESULTS
	system("/sbin/iptables -F");
	system("/sbin/iptables -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT ");
	system("/sbin/iptables -A INPUT -i lo -j ACCEPT ");
	
    	
	system("/sbin/iptables -A INPUT -m state --state NEW -m tcp -p tcp -s houseofaromas.com --match multiport --dports 7851,4252,5396,5566,22,2154,80 -j ACCEPT ");
	system("/sbin/iptables -A INPUT -m state --state NEW -m tcp -p tcp -s 105.155.254.133 --match multiport --dports 5396,7851,4252,5566,22,2154,80 -j ACCEPT ");

 	####################  small api 
 	system("/sbin/iptables -I INPUT -m set --match-set ipv4 src -p tcp --destination-port 80 -j ACCEPT");
 	system("/sbin/iptables -I INPUT -m set --match-set ipv4 src -p tcp --destination-port 22 -j DROP");
	system("/sbin/iptables -I INPUT -m set --match-set ipv4 src -p tcp --destination-port 443 -j DROP");
    system("/sbin/iptables -I INPUT -m set --match-set ipv4 src -p tcp --destination-port 5566 -j DROP");



    system("/sbin/iptables -A INPUT -p tcp --dport 2154 -j DROP;");
    system("/sbin/iptables -A INPUT -p tcp --dport 22 -j DROP;");
    system("/sbin/iptables -A INPUT -p tcp --dport 54321 -j DROP;");

       system("service iptables save;");
       system("service iptables restart;");